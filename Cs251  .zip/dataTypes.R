A <- "Abc";
print(class(A));

A <- 123;
print(class(A));

A<-TRUE;
print (class(A));