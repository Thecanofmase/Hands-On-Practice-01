#Create variable A with value 1
a <-1;
#Create variable B with value 2
b <- 2;
#Calculate A divide B
a / b;
#Calculate A times B
a * b;
#Calculate A plus B
a + b;
#Calculate A subtract B
a - b; 
#Calculate A to the power of 2
a^2;
#Calculate B to the power of 2
b^2;