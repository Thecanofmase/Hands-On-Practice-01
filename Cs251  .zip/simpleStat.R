#Calculate the standard deviation of vector of numbers
print(sd(c(1, 2, 3, 4, 5, 6)))

#Calculate the mean of a vector of numbers 
print(mean(c(1, 2, 3, 4, 5, 6)))

#Calculate the minimum number
print(min(c(1, 2, 3, 4, 5, 6)))