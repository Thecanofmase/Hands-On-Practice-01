A <-"123";
print(is.numeric(A));

print(is.character(A));

B <- 2;
A<-as.numeric(A)
print (A + B);
