v<- c(10,12,13);
b<- c(3,4,5);

print(v+b);
print (v-b);
print (v*b);